package com.lms.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lms.dao.JDBCUserDao;
import com.lms.dao.UserDao;
import com.lms.service.EmployeeServiceImp;
import com.lms.service.UserServiceImpl;


	@WebServlet("/UserController")
	public class UserController extends HttpServlet 
	{
		private static final long serialVersionUID = 1L;
	       
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
		{
			
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}

		
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
		{
			int empId = Integer.parseInt(request.getParameter("empId"));
			String password = request.getParameter("pass");
			
			HttpSession session = request.getSession();
			session.setAttribute("empId", empId);
			
			//System.out.println(empId + " " + password);
			String empType = null;
			JDBCUserDao userDao = new JDBCUserDao();
			UserServiceImpl serviceImpl = new UserServiceImpl();
			try 
			{
				empType = serviceImpl.employeeLogin(empId, password);
				System.out.println(empType);
			}
			catch (SQLException e) 
			{
				
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(empType != null)
			{
				if(empType.equals("hr"))
				{
					session.setAttribute("emp_id", empId);
					response.sendRedirect("hrpage.jsp");
				}
				else if(empType.equals("emp"))
				{
					session.setAttribute("emp_id", empId);
					response.sendRedirect("employeePage.jsp");
				}
				else if(empType.equals("mgr"))
				{
					session.setAttribute("emp_id", empId);
					response.sendRedirect("managerPage.jsp");
				}
				
			}
			else
			{
				System.out.println("Test");
			}
			
		}
	}

