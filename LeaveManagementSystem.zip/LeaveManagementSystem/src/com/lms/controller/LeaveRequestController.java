package com.lms.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lms.dao.JDBCEmployeeDao;
import com.lms.entities.Employee;
import com.lms.entities.Leaves;
import com.lms.service.EmployeeServiceImp;

/**
 * Servlet implementation class RequestLeave
 */
@WebServlet("/LeaveRequestController")
public class LeaveRequestController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Employee employee = null;
		
		HttpSession session = request.getSession();
		int empId = (int) session.getAttribute("empId");
		
		EmployeeServiceImp empService = new EmployeeServiceImp();
		JDBCEmployeeDao empDao = new JDBCEmployeeDao();
		
		try 
		{
			employee = empDao.getEmployeeById(empId);
			
		} catch (ClassNotFoundException | SQLException e1) 
		{
			
			e1.printStackTrace();
		}
		
		
		String leaveType = request.getParameter("leaveType");
		String fromDate = request.getParameter("from_date");
		String toDate = request.getParameter("to_date");
		String leaveDescription = request.getParameter("comments");
		
		Leaves leave = new Leaves(empId, leaveType, fromDate, toDate, employee.getDesignation() ,leaveDescription);
		try {
			
			if(empService.requestLeave(leave, empId))
			{
				request.getRequestDispatcher("employeePage.jsp").forward(request, response);
			}
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		System.out.println(leaveType + fromDate + toDate + leaveDescription + employee.getDesignation());
		
	}
	
//	protected void doRequestLeave(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		
//		
//	}
	

}
