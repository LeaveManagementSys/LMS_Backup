package com.lms.entities;

public class User 
{
	private int EmpId;
	private String password;
	
	public User() {
	}

	public int getEmpId() {
		return EmpId;
	}

	public void setEmpId(int empId) {
		EmpId = empId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [EmpId=" + EmpId + ", password=" + password + "]";
	}

	

	
}
