package com.lms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface UserDao 
{
	public ResultSet employeeLogin(int empId, String password) throws ClassNotFoundException, SQLException;
}
