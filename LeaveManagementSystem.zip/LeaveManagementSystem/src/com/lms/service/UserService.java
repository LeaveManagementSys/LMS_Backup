package com.lms.service;

import java.sql.SQLException;

public interface UserService 
{
	public String employeeLogin(int empId, String password) throws ClassNotFoundException, SQLException; 
}
