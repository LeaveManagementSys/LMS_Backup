package com.lms.service;

import java.sql.SQLException;

import java.util.List;

import com.lms.entities.LeaveBalance;



public interface LeaveService 
{
		public LeaveBalance viewLeaveBalances(int empId) throws ClassNotFoundException, SQLException;
}
