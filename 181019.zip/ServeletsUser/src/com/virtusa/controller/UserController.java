package com.virtusa.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.BasicConfigurator;

import com.virtusa.DAO.UserDAOImp;
import com.virtusa.DAO.UserDao;
import com.virtusa.entities.User;
import com.virtusa.helper.UserData;
import com.virtusa.model.UserModel;
import com.virtusa.service.UserService;
import com.virtusa.service.UserServiceImp;
import com.virtusa.view.EmployeeView;
import com.virtusa.view.HrMainView;
import com.virtusa.view.ManagerView;

public class UserController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private UserService userService=null;
	/**
     * @see HttpServlet#HttpServlet()
     */
	 public UserController() {
	        super();
	        // TODO Auto-generated constructor stub
	    }
	 @Override
	    public void init(ServletConfig config) throws ServletException {
	    	super.init(config);
	    	this.userService=UserData.createUserService();
	 }   		
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        response.getWriter().append("Served at: ").append(request.getContextPath()); }
	        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
	                  Logger logger = Logger.getLogger(UserController.class);
	                  BasicConfigurator.configure();
	        	
	        	String action=request.getParameter("action");
	    		
	    		if(action.contentEquals("login")) {
	    			List<UserModel> userModelList=UserDAOImp.userVerification(int empId,String password);
	    		}
	        	
	                  int empId = Integer.parseInt(request.getParameter("empId"));
	                  String password = request.getParameter("pass");
	                  HttpSession session = request.getSession();
	                  session.setAttribute("empId", empId);
	                  String empType = null;
	                  UserDao userDao = new UserDAOImp();
	                  UserServiceImp serviceImp = new UserServiceImp();
	                  
	                  empType = serviceImp.authenticateService(userModel)
	                  System.out.println(empType);
	                  if(empType != null) {
	                      logger.info("Employee Type is "+ empType);
	                      if(empType.equals("hr")){
	                          session.setAttribute("emp_id", empId);
	                          response.sendRedirect("hrpage.jsp");}
	                      else if(empType.equals("emp")) {
	                          session.setAttribute("emp_id", empId);
	                          response.sendRedirect("employeePage.jsp"); }
	                      else if(empType.equals("mgr"))
	                      {  session.setAttribute("emp_id", empId);
	                          response.sendRedirect("managerPage.jsp");   } }
	                  else
	                  {
	                      logger.info("Employee Type is Null");
	                  }		
	    }    	
             } 