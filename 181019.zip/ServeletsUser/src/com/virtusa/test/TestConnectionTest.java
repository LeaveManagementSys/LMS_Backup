package com.virtusa.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Test;

public class TestConnectionTest {

	/*@After
	public void tearDown() throws Exception {
	}*/

	@Test
	public void test() {
			
		fail("Not yet implemented");
	
	}

}


/*class DeleteDaoTest {

@Test
void testDeleteEmployee_postive() {

Employee employee=new Employee();
EmployeeDao employeedao=new EmployeeDaoImpl();    
employee.setEmployeeId(120);

try {
    boolean actualResult=employeedao.deleteEmployeeDetails(employee);
    boolean expected=true;
    assertEquals(actualResult,expected);            
} catch (ClassNotFoundException e) {
    assertTrue(true);
    // TODO Auto-generated catch block
    e.printStackTrace();
} catch (SQLException e) {
    assertTrue(true);
    // TODO Auto-generated catch block
    e.printStackTrace();
}        
}*/