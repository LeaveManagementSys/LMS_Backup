package com.virtusa.service;

import java.sql.SQLException;

import com.virtusa.model.UserModel;

public interface UserService {
	String authenticateService(UserModel userModel) throws ClassNotFoundException, SQLException;
}//user model is passed here to authenticate the user
