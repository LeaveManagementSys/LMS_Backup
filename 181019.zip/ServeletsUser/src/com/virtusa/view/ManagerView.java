package com.virtusa.view;

public class ManagerView {
	
	public void managerPage() {
		// TODO Auto-generated method stub
		
	}
}

