package com.virtusa.view;

public class HrMainView {

	public void hrMainView() {
		
	}
}
