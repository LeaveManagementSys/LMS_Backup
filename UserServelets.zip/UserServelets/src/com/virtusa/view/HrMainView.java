package com.virtusa.view;

public class HrMainView {

	public void hrMainView() {
		//implemented in HR module
	}
}
