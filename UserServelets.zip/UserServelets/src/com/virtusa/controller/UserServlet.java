package com.virtusa.controller;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.String;
import java.sql.SQLException;

import org.apache.log4j.BasicConfigurator;

import com.virtusa.DAO.UserDAOImp;
import com.virtusa.DAO.UserDao;
import com.virtusa.helper.UserData;
import com.virtusa.model.UserModel;
import com.virtusa.service.UserService;
import com.virtusa.service.UserServiceImp;

/**
 * Servlet implementation class UserServelet
 */
@WebServlet("/login")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService userService=null;
	private UserServiceImp userServiceImp=null;
	 UserModel userModel=new UserModel();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    @Override
    public void init(ServletConfig config) throws ServletException {
    	super.init(config);
    	this.userService=UserData.createUserService();
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//Logger logger = Logger.getLogger(UserServlet.class);
		Logger logger=null;
		BasicConfigurator.configure();
		
		String action=request.getParameter("action");
		if(action.contentEquals("login")) {	
			
			List<UserModel> userModelList = null;
			try {
				userModelList = userService.getuserList();
			} catch (ClassNotFoundException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			request.setAttribute("userModelList", userModelList);
			
			int empId = Integer.parseInt(request.getParameter("emp_id"));
			String password = request.getParameter("pass");
			HttpSession session = request.getSession();
			session.setAttribute("emp_id", empId);
			String empType = null;
			/*UserDao userDao = new UserDAOImp();*/
			UserServiceImp serviceImp = new UserServiceImp();
			UserModel userModel = null;
			try {
				empType = userServiceImp.authenticateService(userModel);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			logger.info(empType);

			if (empType != null) {
				logger.info("Employee Type is " + empType);
				if (empType.equals("HR")) {
					//session.setAttribute("emp_id", empId);
					RequestDispatcher dispatcher=
							request.getRequestDispatcher("hr.jsp");
				} else if (empType.equals("EMPLOYEE")) {
					//session.setAttribute("emp_id", empId);
					RequestDispatcher dispatcher=
							request.getRequestDispatcher("employee.jsp");
				} else if (empType.equals("MANAGER")) {
					//session.setAttribute("emp_id", empId);
					RequestDispatcher dispatcher=
							request.getRequestDispatcher("manager.jsp");
					dispatcher.forward(request, response);
				}
			}

			else {
				logger.info("Employee Not Found Authentication Failed Please try again");
				((HttpServletResponse) session).sendRedirect("welcome.jsp");
			}
		}

		}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doGet(request, response);
	}

}
