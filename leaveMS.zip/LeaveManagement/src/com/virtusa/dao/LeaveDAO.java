package com.virtusa.dao;

public class LeaveDAO {

}
