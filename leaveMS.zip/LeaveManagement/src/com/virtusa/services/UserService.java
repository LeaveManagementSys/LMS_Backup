package com.virtusa.services;

import com.virtusa.model.UserModel;

public interface UserService {

	public String authenticateService(UserModel userModel);
}
