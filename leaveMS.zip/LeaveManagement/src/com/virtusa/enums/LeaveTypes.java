package com.virtusa.enums;

public class LeaveTypes {

}
